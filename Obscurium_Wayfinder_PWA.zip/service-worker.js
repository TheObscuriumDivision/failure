
self.addEventListener("install", function(e) {
  e.waitUntil(
    caches.open("obscurium-cache").then(function(cache) {
      return cache.addAll([
        "/index.html",
        "/manifest.json",
        "/service-worker.js",
        "/js/cipher.js",
        "/js/forge.js",
        "/js/morse.js",
        "/js/compass.js",
        "/js/clock.js",
        "/js/badge.js",
        "/js/hidden.js"
      ]);
    })
  );
});

self.addEventListener("fetch", function(e) {
  e.respondWith(
    caches.match(e.request).then(function(response) {
      return response || fetch(e.request);
    })
  );
});
