
document.addEventListener("DOMContentLoaded", () => {
  const main = document.querySelector("main");
  main.innerHTML = `
    <div style="text-align: center;">
      <h2>Brass Compass</h2>
      <div id="compassContainer" style="margin: auto; width: 300px; height: 300px; position: relative;">
        <img id="gearBase" src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/Gear_icon.svg/300px-Gear_icon.svg.png" 
             style="width: 100%; height: 100%; transform-origin: center; position: absolute; z-index: 1;"/>
        <img id="needle" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Compass_rose_pale.svg/300px-Compass_rose_pale.svg.png" 
             style="width: 100%; height: 100%; transform-origin: center; position: absolute; z-index: 2;"/>
      </div>
      <p id="headingDisplay">Heading: ...</p>
      <button onclick="pinLocation()">📍 Pin Location</button>
      <ul id="pinnedLocations"></ul>
    </div>
  `;

  let headingDisplay = document.getElementById("headingDisplay");
  let gearBase = document.getElementById("gearBase");
  let needle = document.getElementById("needle");
  let pinnedList = document.getElementById("pinnedLocations");

  let pins = [];

  if (window.DeviceOrientationEvent) {
    window.addEventListener("deviceorientationabsolute", handleOrientation, true);
    window.addEventListener("deviceorientation", handleOrientation, true);
  }

  let gearAngle = 0;

  function handleOrientation(event) {
    let alpha = event.alpha;
    if (alpha !== null) {
      needle.style.transform = `rotate(${360 - alpha}deg)`;
      headingDisplay.textContent = `Heading: ${Math.round(alpha)}°`;
    }

    // Gear rotates independently
    gearAngle = (gearAngle + 1) % 360;
    gearBase.style.transform = `rotate(${gearAngle}deg)`;
  }

  window.pinLocation = function() {
    const heading = headingDisplay.textContent.replace("Heading: ", "");
    pins.push(heading);
    const li = document.createElement("li");
    li.textContent = `📌 ${heading}`;
    pinnedList.appendChild(li);
  };
});
