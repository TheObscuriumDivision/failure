
document.addEventListener("DOMContentLoaded", () => {
  const main = document.querySelector("main");
  main.innerHTML = `
    <div style="text-align: center;">
      <h2>Message Forge</h2>
      <textarea id="inputMessage" placeholder="Enter your message..." rows="4" cols="40"></textarea><br/>
      <select id="encodingMethod">
        <option value="morse">Morse Code</option>
        <option value="riddle">Riddle</option>
        <option value="glyph">Animated Glyphs</option>
      </select>
      <br/><br/>
      <button onclick="encodeMessage()">Encode</button>
      <pre id="outputMessage" style="margin-top: 10px;"></pre>
    </div>
  `;
});

// Morse Code mapping
const MORSE = {
  a: ".-", b: "-...", c: "-.-.", d: "-..", e: ".", f: "..-.",
  g: "--.", h: "....", i: "..", j: ".---", k: "-.-", l: ".-..",
  m: "--", n: "-.", o: "---", p: ".--.", q: "--.-", r: ".-.",
  s: "...", t: "-", u: "..-", v: "...-", w: ".--", x: "-..-",
  y: "-.--", z: "--..", " ": " / "
};

function encodeMessage() {
  const input = document.getElementById("inputMessage").value.toLowerCase();
  const method = document.getElementById("encodingMethod").value;
  let output = "";

  if (method === "morse") {
    output = input.split('').map(c => MORSE[c] || '').join(' ');
  } else if (method === "riddle") {
    output = input.split(' ').map(word => `What walks like "${word}" but isn't?`).join('\n');
  } else if (method === "glyph") {
    output = input.split('').map(c => {
      const code = c.charCodeAt(0);
      return String.fromCharCode(0x16A0 + (code % 26)); // Fake rune-ish glyph
    }).join(' ');
  }

  document.getElementById("outputMessage").textContent = output;
}
