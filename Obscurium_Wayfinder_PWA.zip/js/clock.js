
document.addEventListener("DOMContentLoaded", () => {
  const main = document.querySelector("main");
  main.innerHTML = \`
    <div style="text-align: center;">
      <h2>Mission Clock</h2>
      <p id="localTime"></p>
      <p id="agentTime"></p>
      <input type="number" id="offsetInput" value="5" style="width: 50px;"> hr offset
      <button onclick="updateAgentTime()">Set Agent Time</button>
      <hr>
      <h3>Countdown Timer</h3>
      <input type="number" id="countdownInput" value="60" style="width: 60px;"> seconds
      <button onclick="startCountdown()">Start</button>
      <p id="countdownDisplay"></p>
    </div>
  \`;

  updateClock();
  setInterval(updateClock, 1000);
});

function updateClock() {
  const now = new Date();
  document.getElementById("localTime").textContent = "Local Time: " + now.toLocaleTimeString();
  updateAgentTime();
}

function updateAgentTime() {
  const offset = parseInt(document.getElementById("offsetInput").value) || 0;
  const now = new Date();
  const agentTime = new Date(now.getTime() + offset * 3600 * 1000);
  document.getElementById("agentTime").textContent = "Agent Time: " + agentTime.toLocaleTimeString();
}

function startCountdown() {
  let seconds = parseInt(document.getElementById("countdownInput").value) || 60;
  const display = document.getElementById("countdownDisplay");

  const timer = setInterval(() => {
    if (seconds > 0) {
      display.textContent = "⏳ " + seconds + "s remaining...";
      seconds--;
    } else {
      clearInterval(timer);
      display.textContent = "💥 Mission Time Reached!";
      if (navigator.vibrate) navigator.vibrate([300, 100, 300]);
    }
  }, 1000);
}
