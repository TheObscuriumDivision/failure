
// Cipher Crank Tool: Caesar, Atbash, Pigpen

document.addEventListener("DOMContentLoaded", () => {
  const input = document.createElement("textarea");
  input.placeholder = "Enter message...";
  const output = document.createElement("textarea");
  output.placeholder = "Decoded output...";
  output.readOnly = true;

  const methodSelect = document.createElement("select");
  ["Caesar", "Atbash", "Pigpen"].forEach(m => {
    const opt = document.createElement("option");
    opt.value = m.toLowerCase();
    opt.textContent = m;
    methodSelect.appendChild(opt);
  });

  const shiftInput = document.createElement("input");
  shiftInput.type = "number";
  shiftInput.value = 3;
  shiftInput.placeholder = "Shift (Caesar only)";

  const decodeButton = document.createElement("button");
  decodeButton.textContent = "Decode";

  const container = document.querySelector("main");
  container.innerHTML = "";
  container.appendChild(methodSelect);
  container.appendChild(shiftInput);
  container.appendChild(input);
  container.appendChild(decodeButton);
  container.appendChild(output);

  decodeButton.addEventListener("click", () => {
    const method = methodSelect.value;
    const text = input.value;
    const shift = parseInt(shiftInput.value);
    let result = "";

    switch (method) {
      case "caesar":
        result = caesarDecode(text, shift);
        break;
      case "atbash":
        result = atbashDecode(text);
        break;
      case "pigpen":
        result = pigpenDecode(text);
        break;
      default:
        result = "Unknown method";
    }

    output.value = result;
  });
});

// Caesar Cipher
function caesarDecode(str, shift) {
  return str.replace(/[a-z]/gi, c => {
    const base = c >= 'a' ? 97 : 65;
    return String.fromCharCode((c.charCodeAt(0) - base - shift + 26) % 26 + base);
  });
}

// Atbash Cipher
function atbashDecode(str) {
  return str.replace(/[a-z]/gi, c => {
    const base = c >= 'a' ? 97 : 65;
    return String.fromCharCode(base + (25 - (c.charCodeAt(0) - base)));
  });
}

// Pigpen Cipher (simple placeholder)
function pigpenDecode(str) {
  const pigpen = {
    a: "⍀", b: "⍁", c: "⍂", d: "⍃", e: "⍄", f: "⍅", g: "⍆", h: "⍇", i: "⍈",
    j: "⍉", k: "⍊", l: "⍋", m: "⍌", n: "⍍", o: "⍎", p: "⍏", q: "⍐", r: "⍑",
    s: "⍒", t: "⍓", u: "⍔", v: "⍕", w: "⍖", x: "⍗", y: "⍘", z: "⍙"
  };
  return str.toLowerCase().split('').map(c => pigpen[c] || c).join('');
}
