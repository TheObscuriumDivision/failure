
document.addEventListener("DOMContentLoaded", () => {
  const main = document.querySelector("main");
  main.innerHTML = `
    <div style="text-align: center;">
      <h2>Tap corners to reveal hidden mode...</h2>
      <div id="hiddenOutput" style="margin-top: 20px; font-size: 20px; color: #b08d57;"></div>
    </div>
  `;

  let pattern = [];
  let requiredPattern = ["TL", "TR", "BL", "BR"]; // Top-left, top-right, bottom-left, bottom-right
  let activated = false;

  document.addEventListener("click", (e) => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const x = e.clientX;
    const y = e.clientY;
    const threshold = 100;

    let corner = null;
    if (x < threshold && y < threshold) corner = "TL";
    else if (x > width - threshold && y < threshold) corner = "TR";
    else if (x < threshold && y > height - threshold) corner = "BL";
    else if (x > width - threshold && y > height - threshold) corner = "BR";

    if (corner) {
      pattern.push(corner);
      if (pattern.length > requiredPattern.length) pattern.shift();

      if (JSON.stringify(pattern) === JSON.stringify(requiredPattern) && !activated) {
        activated = true;
        revealHiddenMode();
      }
    }
  });

  function revealHiddenMode() {
    document.getElementById("hiddenOutput").innerHTML = "🔓 Hidden Mode Activated! Welcome, Agent.";
    document.body.style.background = "#111";
    document.body.style.color = "#b08d57";
    document.querySelector("main").innerHTML += "<p><strong>Mission Archive Access Granted.</strong></p>";
  }
});
