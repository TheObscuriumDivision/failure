
document.addEventListener("DOMContentLoaded", () => {
  const main = document.querySelector("main");
  main.innerHTML = `
    <div style="text-align: center; font-family: 'Courier New', Courier, monospace;">
      <h2>Agent Identification</h2>
      <div id="badgeCard" style="border: 4px solid #b08d57; padding: 20px; background: #1d1d1b; color: #e2c290; width: 300px; margin: auto; border-radius: 10px;">
        <img id="agentPhoto" src="https://www.fillmurray.com/200/200" alt="Agent" style="border: 2px solid #b08d57; width: 100px; height: 100px; border-radius: 50%;"><br/>
        <h3 id="agentName">Agent Lucien Vale</h3>
        <p id="agentAlias">Codename: Obsidian Wolf</p>
        <p id="agentDivision">Division: Temporal Recon</p>
        <p id="agentID">ID: OW-7421-ZX</p>
      </div>
      <button style="margin-top: 10px;" onclick="shuffleIdentity()">🔀 Shuffle Identity</button>
    </div>
  `;

  window.shuffleIdentity = () => {
    const agents = [
      {
        name: "Agent Lucien Vale",
        alias: "Obsidian Wolf",
        division: "Temporal Recon",
        id: "OW-7421-ZX",
        photo: "https://www.fillmurray.com/200/200"
      },
      {
        name: "Agent Astra Dray",
        alias: "Crimson Specter",
        division: "Cipher Division",
        id: "CS-1138-RA",
        photo: "https://placekitten.com/200/200"
      },
      {
        name: "Agent Silas Vex",
        alias: "Brass Phantom",
        division: "Obscura Ops",
        id: "BP-9012-KG",
        photo: "https://placebear.com/200/200"
      }
    ];

    const random = agents[Math.floor(Math.random() * agents.length)];
    document.getElementById("agentName").textContent = random.name;
    document.getElementById("agentAlias").textContent = "Codename: " + random.alias;
    document.getElementById("agentDivision").textContent = "Division: " + random.division;
    document.getElementById("agentID").textContent = "ID: " + random.id;
    document.getElementById("agentPhoto").src = random.photo;
  };
});
