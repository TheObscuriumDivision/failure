
let morseSequence = "";
let decodeTimeout;
const MORSE_DICT = {
  ".-": "A", "-...": "B", "-.-.": "C", "-..": "D", ".": "E",
  "..-.": "F", "--.": "G", "....": "H", "..": "I", ".---": "J",
  "-.-": "K", ".-..": "L", "--": "M", "-.": "N", "---": "O",
  ".--.": "P", "--.-": "Q", ".-.": "R", "...": "S", "-": "T",
  "..-": "U", "...-": "V", ".--": "W", "-..-": "X", "-.--": "Y",
  "--..": "Z", "/": " "
};

document.addEventListener("DOMContentLoaded", () => {
  const main = document.querySelector("main");
  main.innerHTML = `
    <div style="text-align: center;">
      <h2>Morse Tapper</h2>
      <button id="tapDot" style="width: 100px; height: 100px;">•</button>
      <button id="tapDash" style="width: 100px; height: 100px;">−</button><br/>
      <button id="space" style="margin-top: 10px;">New Letter</button>
      <button id="reset" style="margin-top: 10px;">Clear</button>
      <pre id="sequenceDisplay">Sequence: </pre>
      <pre id="decodedOutput">Output: </pre>
    </div>
  `;

  document.getElementById("tapDot").addEventListener("click", () => tapMorse("."));
  document.getElementById("tapDash").addEventListener("click", () => tapMorse("-"));
  document.getElementById("space").addEventListener("click", decodeMorse);
  document.getElementById("reset").addEventListener("click", resetMorse);
});

function tapMorse(symbol) {
  morseSequence += symbol;
  updateDisplay();

  // Optional: Vibration feedback
  if (navigator.vibrate) {
    navigator.vibrate(symbol === "." ? 100 : 300);
  }

  // Auto-decode after delay
  clearTimeout(decodeTimeout);
  decodeTimeout = setTimeout(decodeMorse, 2000);
}

function decodeMorse() {
  const letter = MORSE_DICT[morseSequence] || "?";
  const output = document.getElementById("decodedOutput");
  output.textContent += letter;
  morseSequence = "";
  updateDisplay();
}

function resetMorse() {
  morseSequence = "";
  document.getElementById("sequenceDisplay").textContent = "Sequence: ";
  document.getElementById("decodedOutput").textContent = "Output: ";
}

function updateDisplay() {
  document.getElementById("sequenceDisplay").textContent = "Sequence: " + morseSequence;
}
